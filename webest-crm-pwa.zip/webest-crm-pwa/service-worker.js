/* Webest CRM service worker – offline cache.
   Bump CACHE_VERSION whenever you upload new files so phones pick up the update. */
const CACHE_VERSION="webest-crm-v3";
const ASSETS=["./", "index.html", "manifest.json", "css/style.css", "js/fields.js", "js/core.js", "js/views.js", "js/charts-quotes.js", "js/extras.js", "js/backup.js", "js/main.js", "libs/xlsx.full.min.js", "libs/jspdf.umd.min.js", "libs/jspdf.plugin.autotable.min.js", "icons/icon-192.png", "icons/icon-512.png", "icons/icon-maskable-512.png", "images/banner.jpg"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(CACHE_VERSION).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()))});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==CACHE_VERSION).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener("fetch",e=>{
  const r=e.request;if(r.method!=="GET"||!r.url.startsWith(self.location.origin))return;
  e.respondWith(caches.match(r,{ignoreSearch:true}).then(hit=>{
    const net=fetch(r).then(res=>{if(res&&res.ok){const c=res.clone();caches.open(CACHE_VERSION).then(x=>x.put(r,c))}return res}).catch(()=>null);
    return hit||net.then(res=>res||(r.mode==="navigate"?caches.match("index.html"):new Response("",{status:504})));
  }));
});
