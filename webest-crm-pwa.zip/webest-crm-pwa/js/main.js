/* Webest CRM – startup */
document.querySelectorAll("nav button[data-v]").forEach(b=>b.onclick=()=>nav(b.dataset.v));
(async function start(){
 await loadData();
 try{navigator.storage&&navigator.storage.persist&&navigator.storage.persist()}catch(e){}
 try{history.replaceState({v:"home"},"")}catch(e){}
 const h=location.hash.slice(1);
 if(h==="new-lead"){route();leadForm()}else if(["leads","custs","quotes","claims","more","earn","wa","set"].includes(h))nav(h);else route();
 setTimeout(checkAlerts,1500);setInterval(checkAlerts,60000);
 addEventListener("online",()=>toast("Back online"));addEventListener("offline",()=>toast("📴 Offline – everything still works"));
})();
if("serviceWorker" in navigator&&location.protocol.startsWith("http"))addEventListener("load",()=>navigator.serviceWorker.register("service-worker.js").catch(()=>{}));
