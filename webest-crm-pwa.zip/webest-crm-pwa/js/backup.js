/* Webest CRM – File download, IndexedDB files, backup/restore, Excel, PDF */
// ---- Backup / Export
const uniq=sp=>{const s=new Set;return sp.filter(f=>!s.has(f[0])&&s.add(f[0]))};
window.backupMenu=()=>{modal(`<h2>💾 Backup Data</h2><p style="color:var(--mute)">Choose output format</p><div class="row"><button onclick="modal();xlsx()">📊 Excel (.xlsx)</button><button class="gold" onclick="modal();pdf()">📄 PDF Report</button></div><div class="row"><button onclick="modal();jsonBackup()">🗂️ Full Backup (.json)</button><button class="ghost" onclick="modal();pickRestore()">♻️ Restore</button></div><p style="font-size:12px;color:var(--mute)">Full Backup includes everything + uploaded documents. Keep a copy in Google Drive / WhatsApp.</p><button class="ghost sm" onclick="modal()">Cancel</button>`)};
const MIME={pdf:"application/pdf",xlsx:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",json:"application/json"};
/* Local download (or phone share-sheet when share=true) – no server involved */
async function saveFile(name,data,share){try{const f=new File([data],name,{type:MIME[name.split(".").pop()]||"application/octet-stream"});
 if(share&&navigator.canShare&&navigator.canShare({files:[f]})){try{await navigator.share({files:[f],title:name});toast("Shared ✅");return}catch(e){if(e.name==="AbortError")return}}
 const u=URL.createObjectURL(f),a=document.createElement("a");a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),5000);toast("Saved to Downloads ✅")}catch(e){toast("Export failed")}}
/* IndexedDB key-value store: app data (key "__data__") + uploaded KYC files */
const idb=()=>new Promise((res,rej)=>{const r=indexedDB.open("webest_files",1);r.onupgradeneeded=()=>r.result.createObjectStore("f");r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
const idbPut=async(k,v)=>{const d=await idb();return new Promise((res,rej)=>{const t=d.transaction("f","readwrite");t.objectStore("f").put(v,k);t.oncomplete=res;t.onerror=()=>rej(t.error);t.onabort=()=>rej(t.error)})};
const idbGet=async k=>{const d=await idb();return new Promise((res,rej)=>{const q=d.transaction("f").objectStore("f").get(k);q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)})};
const idbDel=async k=>{const d=await idb();return new Promise(res=>{const t=d.transaction("f","readwrite");t.objectStore("f").delete(k);t.oncomplete=res;t.onerror=res})};
let _bn;async function bannerData(){if(_bn)return _bn;const b=await(await fetch("images/banner.jpg")).blob();return _bn=await new Promise(r=>{const f=new FileReader;f.onload=()=>r(f.result);f.readAsDataURL(b)})}
window.viewDoc=async(cid,id)=>{const x=cust(cid).docs.find(d=>d.id===id),b=await idbGet(x.aid);if(!b){toast("File not found on this device");return}const u=URL.createObjectURL(b);
 if((b.type||"").startsWith("image/"))modal(`<h2>${esc(x.type)}</h2><img src="${u}" style="max-width:100%;border-radius:10px"><div class="row" style="margin-top:10px"><a href="${u}" download="${esc(x.name)}"><button class="sm gold">⬇️ Download</button></a><button class="sm ghost" onclick="modal()">Close</button></div>`);
 else{const a=document.createElement("a");a.href=u;a.download=x.name;document.body.appendChild(a);a.click();a.remove()}};
async function jsonBackup(){const files={};for(const c of S0.custs)for(const x of c.docs||[])if(x.aid){const b=await idbGet(x.aid);if(b)files[x.aid]=await new Promise(r=>{const fr=new FileReader;fr.onload=()=>r(fr.result);fr.readAsDataURL(b)})}
 await saveFile("Webest_CRM_FullBackup_"+today()+".json",JSON.stringify({app:"webest-crm",v:3,exported:new Date().toISOString(),S0,files}));try{localStorage.setItem("webest_lastbackup",Date.now())}catch(e){}}
window.pickRestore=()=>modal(`<h2>♻️ Restore Backup</h2><p>Choose a Webest Full Backup (.json) file. This replaces ALL data on this device.</p><input type="file" accept=".json,application/json" onchange="restoreFile(this)"><div class="row" style="margin-top:12px"><button class="ghost sm" onclick="modal()">Cancel</button></div>`);
window.restoreFile=async inp=>{try{const j=JSON.parse(await inp.files[0].text());if(!j.S0)throw 0;for(const [id,u] of Object.entries(j.files||{}))await idbPut(id,await (await fetch(u)).blob());S0=j.S0;await idbPut(DK,S0);modal();toast("Restored ✅");setTimeout(()=>location.reload(),600)}catch(e){toast("Invalid backup file")}};
function bkBanner(){if(!S0.custs.length&&!S0.leads.length)return"";let l=0;try{l=+localStorage.getItem("webest_lastbackup")||0}catch(e){}const dd=l?Math.floor((Date.now()-l)/864e5):-1;return dd>=0&&dd<7?"":`<div class="card" style="border-color:var(--warn)">💾 ${dd<0?"No backup taken yet.":"Last backup "+dd+" days ago."} <button class="sm gold" onclick="jsonBackup()">Back up now</button></div>`}
async function xlsx(){const ex=[["_c","Customer"],["_m","Mobile"]],pol=[],mem=[];
 S0.custs.forEach(c=>c.pols.forEach(p=>{pol.push({...p,_c:c.name,_m:c.mobile});if(p.type==="Family Floater")for(let i=0;i<(+p.nmem||2);i++){const r={_c:c.name,_m:c.mobile,polno:p.polno};MF.forEach(f=>r[f[0]]=p["m"+i+"_"+f[0]]);mem.push(r)}}));
 const cn=id=>cust(id)?.name||"",pn=x=>cust(x.cid)?.pols.find(p=>p.id===x.pid)?.polno||"",cp=k=>pol.filter(p=>p.cat===k);
 const add=(wb,n,rows,sp)=>{if(!rows.length)return;sp=uniq(sp);const w=XLSX.utils.aoa_to_sheet([sp.map(f=>f[1].replace(/ \*$/,"")),...rows.map(r=>sp.map(f=>r[f[0]]??""))]);w["!cols"]=sp.map(()=>({wch:22}));XLSX.utils.book_append_sheet(wb,w,n)};
 try{const wb=XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([["WEBEST INSURANCE CORPORATION"],["Data Backup Report"],["Generated on",today()],[],["Leads",S0.leads.length],["Customers",S0.custs.length],["Policies",pol.length],["Claims",S0.claims.length]]),"Cover");
  add(wb,"Leads",S0.leads,[...LB,...Object.values(LC).flat(),...FU,["created","Created On"]]);
  add(wb,"Customers",S0.custs.map(c=>({...c,pols:c.pols.length,ls:c.fromLead?.source||"Direct",famhead:cust(c.famhead)?.name||""})),[...CB,...CK,...CBK,...CH,["refby","Referred By"],["ls","Lead Source"],["pols","No. of Policies"]]);
  add(wb,"Life Policies",cp("Life"),[...ex,...PC,...LP,...FAM,...NOM,...APP,...COV,...DOC,...FEM,...PR]);
  add(wb,"Health Policies",cp("Health"),[...ex,...PC,...HB,["nmem","Family Members"],...HI,...PR]);
  add(wb,"Health Members",mem,[...ex,["polno","Policy No"],...MF]);
  add(wb,"General Policies",cp("General"),[...ex,...PC,...GR,...Object.values(GT).flat(),...GN,...GD,...GAD,...PR]);
  add(wb,"Commission Ledger",pol.map(p=>({...p,_pct:cpct(p),_exp:cexp(p),_rec:rcv(p),_st:p.comm_status||"Payout Pending"})),[["_c","Customer"],["_m","Mobile"],["cat","Category"],["insurer","Insurer"],["polno","Policy No"],["premium","Premium"],["_pct","Commission %"],["_exp","Expected Commission"],["_st","Payout Status"],["_rec","Received"],["comm_date","Received On"],["comm_ref","Remarks"]]);
  add(wb,"Documents",S0.custs.flatMap(c=>(c.docs||[]).map(x=>({_c:c.name,...x,_u:x.aid?"(stored in app)":x.local?"(stored in app)":x.url}))),[["_c","Customer"],["type","Type"],["name","File / Link"],["pol","Policy"],["date","Added On"],["_u","Link"]]);
  add(wb,"Quotations",S0.quotes.map(q=>({...q,total:totals(q).t})),[["qno","Quotation No"],["date","Date"],...QP,...QD,["total","Total Payable (₹)"],...QH]);
  add(wb,"Claims",S0.claims.map(x=>({...x,_c:cn(x.cid),_p:pn(x)})),[["_c","Customer"],["_p","Policy No"],...CL]);
  await saveFile("Webest_Insurance_Backup_"+today()+".xlsx",XLSX.write(wb,{bookType:"xlsx",type:"array"}))}catch(e){toast("Export failed")}}
const cl=s=>String(s??"").replace(/₹/g,"Rs.").replace(/[^\x20-\xFF–—]/g,"").trim();
async function pdf(one){if(!window.jspdf){toast("PDF library not loaded");return}
 const d=new jspdf.jsPDF({unit:"pt",format:"a4"}),W=d.internal.pageSize.getWidth(),bh=W*793/1983,M=40;let y=bh+28;
 d.addImage(await bannerData(),"JPEG",0,0,W,bh);
 const T=(sz,c,b)=>{d.setFont("helvetica",b?"bold":"normal");d.setFontSize(sz);d.setTextColor(...c)};
 T(18,[11,42,91],1);d.text("Webest Insurance Corporation",M,y);y+=18;T(10,[107,118,144]);d.text((one?"Customer Profile - "+cl(one.name):"Business Data Report")+"   |   Generated: "+today(),M,y);y+=10;
 d.setDrawColor(212,160,23);d.setLineWidth(2);d.line(M,y,W-M,y);y+=18;
 const H=t=>{const L=d.splitTextToSize(cl(t),W-2*M);if(y+L.length*14>720){d.addPage();y=50}T(12,[11,42,91],1);d.text(L,M,y);y+=(L.length-1)*14+16};
 const tbl=(head,body)=>{if(!body.length){T(9,[107,118,144]);d.text("No records",M,y);y+=30;return}d.autoTable({startY:y,head:[head],body,theme:"grid",margin:{left:M,right:M},styles:{fontSize:8,cellPadding:4},headStyles:{fillColor:[11,42,91]},alternateRowStyles:{fillColor:[244,246,251]}});y=d.lastAutoTable.finalY+18};
 const lab={fontStyle:"bold",fillColor:[244,246,251],cellWidth:100};
 const kv=(t,secs,o)=>{const r=[];secs.forEach(s=>s.f.forEach(f=>{const v=o[s.pre+f[0]];if(v!==undefined&&v!==null&&v!=="")r.push([cl(f[1].replace(" *","")),cl(v)])}));if(!r.length)return;H(t);const b=[];for(let i=0;i<r.length;i+=2)b.push([...r[i],...(r[i+1]||["",""])]);d.autoTable({startY:y,body:b,theme:"grid",margin:{left:M,right:M},styles:{fontSize:8,cellPadding:4},columnStyles:{0:lab,2:lab}});y=d.lastAutoTable.finalY+14};
 const crow=x=>[cl(cust(x.cid)?.name),cl(cust(x.cid)?.pols.find(p=>p.id===x.pid)?.polno),cl(x.type),cl(x.amt),cl(x.appr),cl(x.status),x.next||""],CH2=["Customer","Policy No","Type","Claimed","Approved","Status","Next Follow-up"];
 const prof=c=>{if(!one){d.addPage();y=50}H("CUSTOMER: "+c.name.toUpperCase());kv("Personal, KYC & Bank Details",[S("",CB),S("",CK),S("",CBK),S("",CH)],c);c.pols.forEach(p=>kv(p.cat+" Policy - "+(p.insurer||"")+" "+(p.polno||""),polSecs(p,c),p));const cls=S0.claims.filter(x=>x.cid===c.id);if(cls.length){H("Claims");tbl(CH2,cls.map(crow))}};
 if(one)prof(one);else{const pl=S0.custs.flatMap(c=>c.pols.map(p=>({c,p}))),prem=pl.reduce((a,{p})=>a+(+p.premium||0),0);
  H("Summary");tbl(["Metric","Value"],[["Open Leads",S0.leads.length],["Customers",S0.custs.length],["Total Policies",pl.length],["Life / Health / General",["Life","Health","General"].map(k=>pl.filter(({p})=>p.cat===k).length).join(" / ")],["Total Premium (Rs.)",prem.toLocaleString("en-IN")],["Open Claims",S0.claims.filter(open).length],["Leads Converted",S0.custs.filter(c=>c.fromLead).length]]);
  H("Leads");tbl(["Name","Mobile","City","Interest","Status","Next Follow-up","Source"],S0.leads.map(l=>[cl(l.name),cl(l.mobile),cl(l.city),l.cat,l.status,l.next||"",cl(l.source)]));
  H("Customers");tbl(["Name","Mobile","City","Life","Health","General","Referred By"],S0.custs.map(c=>[cl(c.name),cl(c.mobile),cl(c.city),...["Life","Health","General"].map(k=>c.pols.filter(p=>p.cat===k).length),cl(c.refby)]));
  H("Policies");tbl(["Customer","Category","Insurer","Policy No","Plan / Type","Premium","Sum","Due","Status"],pl.map(({c,p})=>[cl(c.name),p.cat,cl(p.insurer),cl(p.polno),cl(p.plan||p.type),cl(p.premium),cl(p.sum),p.due||"",p.status]));
  H("Quotations");tbl(["Quote No","Customer","Insurer / Plan","Total Payable","Valid Until","Status"],S0.quotes.map(q=>[cl(q.qno),cl(q.qname),cl(q.insurer+" - "+q.qplan),money(totals(q).t),q.valid||"",q.status]));H("Claims");tbl(CH2,S0.claims.map(crow));S0.custs.forEach(prof)}
 const n=d.getNumberOfPages();for(let i=1;i<=n;i++){d.setPage(i);T(8,[107,118,144]);d.text("Webest Insurance Corporation  |  Confidential",M,824);d.text("Page "+i+" of "+n,W-M,824,{align:"right"})}
 await saveFile("Webest_"+(one?cl(one.name).replace(/\W+/g,"_"):"Report")+"_"+today()+".pdf",d.output("arraybuffer"))}
