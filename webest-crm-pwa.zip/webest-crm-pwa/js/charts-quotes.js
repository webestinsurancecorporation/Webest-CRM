/* Webest CRM – Analytics charts and quotations */
// ---- Charts
const bars=(a,f=x=>x)=>{const m=Math.max(1,...a.map(i=>i[1]));return a.map(([l,n])=>`<div class="bar"><span>${l}</span><div><i style="width:${n/m*100}%"></i></div><b>${f(n)}</b></div>`).join("")};
window.tg=()=>{UI.charts=!UI.charts;try{localStorage.setItem(K+"_ui",JSON.stringify(UI))}catch(e){}route()};
function chartsCard(){const hd=`<div class="row" style="justify-content:space-between;margin:0"><h2 style="margin:0">📊 Analytics</h2><button class="sm ghost" onclick="tg()">${UI.charts?"🙈 Hide":"👁️ View"}</button></div>`;if(!UI.charts)return`<div class="card">${hd}</div>`;
 const cats=["Life","Health","General"],col={Life:"#b4337a",Health:"#1b9e5a",General:"#2d6cdf"},all=S0.custs.flatMap(c=>c.pols),cn=cats.map(k=>all.filter(p=>p.cat===k).length),tot=cn.reduce((a,b)=>a+b,0);
 let ac=0;const cg=tot?cats.map((k,i)=>{const a=ac/tot*360;ac+=cn[i];return`${col[k]} ${a}deg ${ac/tot*360}deg`}).join(","):"#c9d1e4 0deg 360deg";
 const mo=[...Array(6)].map((_,i)=>{const d=new Date();d.setDate(1);d.setMonth(d.getMonth()+i);const k=ds(d).slice(0,7);return[d.toLocaleString("en",{month:"short",year:"2-digit"}),all.filter(p=>p.status==="Active"&&(p.due||"").startsWith(k)).length]});
 const cs=["Intimated","Documents Pending","Under Review","Approved","Settled","Rejected"].map(s=>[s.replace("Documents ","Docs "),S0.claims.filter(x=>x.status===s).length]);
 const pr=cats.map(k=>[k,Math.round(all.filter(p=>p.cat===k).reduce((a,p)=>a+(+p.premium||0),0))]);
 return`<div class="card">${hd}<h3>Lead pipeline</h3>${bars(["New","Contacted","Interested","Quote Sent","Follow-up","Lost"].map(s=>[s,S0.leads.filter(l=>l.status===s).length]))}
 <h3>Policies by category</h3><div class="row" style="margin:0;gap:16px"><div class="donut" style="background:conic-gradient(${cg})"><div>${tot}</div></div><div>${cats.map((k,i)=>`<div><span style="color:${col[k]}">●</span> ${k}: <b>${cn[i]}</b></div>`).join("")}</div></div>
 <h3>Annual premium by category</h3>${bars(pr,n=>"₹"+n.toLocaleString("en-IN"))}<h3>Renewals / premiums due – next 6 months</h3>${bars(mo)}<h3>Leads by source</h3>${bars(SRC.split(",").map(s=>[s,S0.leads.filter(l=>l.source===s).length]).filter(x=>x[1]))||"<div class=empty>No leads</div>"}<h3>Quotations by status</h3>${bars(["Draft","Sent","Accepted","Rejected","Expired"].map(s=>[s,S0.quotes.filter(q=>q.status===s).length]))}<h3>Claims by status</h3>${bars(cs)}</div>`}
// ---- Quotations
const QP=P("qname|Customer Name *;qmobile|Mobile Number|m;qemail|Email|e;qcity|City;qage|Age / DOB");
const QD=P("cat|Insurance Category *|s|Life,Health,General;insurer|Insurer / Company *;qplan|Plan / Product *;ident|Insured Details (life assured / members / vehicle & IDV);sum|Sum Assured / Insured (₹)|n;term|Policy Term / Period;mode|Premium Mode|s|Yearly,Half-yearly,Quarterly,Monthly,Single;premium|Premium Before Tax (₹) *|n;gst|GST / Tax (%) – leave blank if not applicable|n;valid|Quotation Valid Until|d;status|Quotation Status|s|Draft,Sent,Accepted,Rejected,Expired;sent|Sent On|d");
const QH=P("benefits|Key Benefits (one per line)|a;addons|Add-ons / Riders Included (one per line)|a;excl|Key Exclusions / Conditions (one per line)|a;qnotes|Remarks to Customer|a");
const CO={name:"Webest Insurance Corporation",email:"webestinsurancecorporation@gmail.com",phone:"9841377512",addr:"No.2/102, Bharathi Nagar East Street, Kakkanji colony, Vysarpadi, Sharma Nagar, Chennai - 600039"};
const totals=q=>{const b=+q.premium||0,g=+q.gst||0,ga=Math.round(b*g)/100;return{b,g,ga,t:b+ga}};
const money=n=>"Rs. "+Math.round(n).toLocaleString("en-IN");
const qrow=q=>`<div class="it" onclick="quoteForm('${q.id}')"><div><b>${esc(q.qno)}</b><small>${esc(q.qname)} · ${esc(q.insurer)} – ${esc(q.qplan)}</small><br>${tag(q.cat)}<span class="tag">${esc(q.status)}</span><span class="tag">${money(totals(q).t)}</span></div><div class="row" style="flex-direction:column;align-items:stretch;margin:0"><button class="sm" onclick="event.stopPropagation();qdl('${q.id}')">📄 PDF</button><button class="sm" style="background:var(--ok)" onclick="event.stopPropagation();qSend('${q.id}')">💬 Send</button></div></div>`;
window.qdl=id=>qpdf(S0.quotes.find(q=>q.id===id));
const qCard=(ft,id)=>{const a=S0.quotes.filter(q=>q.forType===ft&&q.refId===id);return a.length?`<div class="card"><h2>Quotations (${a.length})</h2>${a.map(qrow).join("")}</div>`:""};
const qBack=d=>d.forType==="cust"&&cust(d.refId)?nav("cust",d.refId):d.forType==="lead"&&S0.leads.find(l=>l.id===d.refId)?nav("leads"):nav("quotes");
function quoteForm(id,pre){const e=id&&S0.quotes.find(q=>q.id===id),no=Math.max(0,...S0.quotes.map(q=>+String(q.qno).split("/").pop()||0))+1;
 draw({title:e?"Edit Quotation "+esc(e.qno):"New Quotation",d:e?{...e}:{id:uid("Q"),qno:"WIC/QT/"+new Date().getFullYear()+"/"+String(no).padStart(4,"0"),date:today(),valid:plus(15),status:"Draft",cat:"Life",...pre},
 secs:()=>[S("Prepared For",QP),S("Quotation Details",QD),S("Plan Highlights",QH)],
 extra:`<button style="background:var(--ok)" onclick="qDl()">💾 Save & Download PDF</button>`,
 save:(d,dl)=>{const i=S0.quotes.findIndex(q=>q.id===d.id);i<0?S0.quotes.unshift(d):S0.quotes[i]=d;save();toast("Quotation saved");if(dl)qpdf(d);qBack(d)},
 del:e&&(()=>{S0.quotes=S0.quotes.filter(q=>q.id!==id);save();qBack(e)}),back:()=>qBack(cur.d)})}
window.quoteForm=quoteForm;
window.qDl=()=>{const m=collect(cur,1);if(m.length){toast("Required: "+m[0]);return}cur.save(cur.d,true)};
window.leadQuote=id=>{const l=S0.leads.find(x=>x.id===id);quoteForm(0,{forType:"lead",refId:id,qname:l.name,qmobile:l.mobile,qemail:l.email,qcity:l.city,qage:l.dob?age(l.dob)+" yrs":"",cat:l.cat})};
window.custQuote=id=>{const c=cust(id);quoteForm(0,{forType:"cust",refId:id,qname:c.name,qmobile:c.mobile,qemail:c.email,qcity:c.city,qage:c.dob?age(c.dob)+" yrs":""})};
function quotes(){const f=B||"All",L=S0.quotes.filter(q=>f==="All"||q.status===f);
 $("#app").innerHTML=`<div class="tabs">${["All","Draft","Sent","Accepted"].map(c=>`<button class="${f===c?"on":""}" onclick="nav('quotes',0,'${c}')">${c}</button>`).join("")}</div><div class="card"><h2>Quotations (${L.length})</h2>${L.length?L.map(qrow).join(""):'<div class="empty">No quotations yet. Open a lead or a customer and tap “Quotation”.</div>'}</div>`}
async function qpdf(q){if(!window.jspdf){toast("PDF library not loaded");return}
 const d=new jspdf.jsPDF({unit:"pt",format:"a4"}),W=d.internal.pageSize.getWidth(),bh=W*793/1983,M=40,tt=totals(q),C=(s)=>cl(s);
 d.addImage(await bannerData(),"JPEG",0,0,W,bh);
 d.setFillColor(11,42,91);d.rect(0,bh,W,66,"F");d.setFillColor(212,160,23);d.rect(0,bh+66,W,3,"F");
 const T=(sz,c,b)=>{d.setFont("helvetica",b?"bold":"normal");d.setFontSize(sz);d.setTextColor(...c)},WH=[255,255,255],NV=[11,42,91],GR=[107,118,144];
 T(16,WH,1);d.text(CO.name.toUpperCase(),W/2,bh+22,{align:"center"});T(9.5,[255,214,102],1);d.text("Email: "+CO.email+"     |     Phone: "+CO.phone,W/2,bh+40,{align:"center"});T(8,WH);d.text(CO.addr,W/2,bh+55,{align:"center"});
 let y=bh+98;T(22,NV,1);d.text("QUOTATION",M,y);T(9,GR);d.text("Quotation No: "+C(q.qno),W-M,y-14,{align:"right"});d.text("Date: "+(q.date||""),W-M,y-1,{align:"right"});d.text("Valid Until: "+(q.valid||"-"),W-M,y+12,{align:"right"});y+=24;
 const H=t=>{if(y>735){d.addPage();y=50}T(11,NV,1);d.text(t,M,y);d.setDrawColor(212,160,23);d.setLineWidth(1.2);d.line(M,y+4,M+60,y+4);y+=12};
 const lab={fontStyle:"bold",fillColor:[244,246,251],cellWidth:110,textColor:NV};
 const kv=rows=>{rows=rows.filter(r=>r[1]);const b=[];for(let i=0;i<rows.length;i+=2)b.push([...rows[i],...(rows[i+1]||["",""])]);d.autoTable({startY:y,body:b,theme:"grid",margin:{left:M,right:M},styles:{fontSize:9,cellPadding:5,lineColor:[225,230,240]},columnStyles:{0:lab,2:lab}});y=d.lastAutoTable.finalY+18};
 H("PREPARED FOR");kv([["Name",C(q.qname)||C(q.qmobile)||"Valued Customer"],["Mobile",C(q.qmobile)],["Email",C(q.qemail)],["City",C(q.qcity)],["Age",C(q.qage)]]);
 H("QUOTATION SUMMARY");kv([["Category",q.cat+" Insurance"],["Insurer",C(q.insurer)],["Plan / Product",C(q.qplan)],["Insured Details",C(q.ident)],["Sum Assured / Insured",q.sum?money(q.sum):""],["Policy Term / Period",C(q.term)],["Premium Mode",q.mode]]);
 H("PREMIUM DETAILS");const rows=[["Premium (before tax)",money(tt.b)]];if(tt.g)rows.push(["GST / Tax @ "+tt.g+"%",money(tt.ga)]);rows.push(["TOTAL PAYABLE ("+(q.mode||"")+")",money(tt.t)]);
 d.autoTable({startY:y,body:rows,theme:"grid",margin:{left:M,right:M},styles:{fontSize:10,cellPadding:6,lineColor:[225,230,240]},columnStyles:{1:{halign:"right",cellWidth:150}},didParseCell:h=>{if(h.row.index===rows.length-1){h.cell.styles.fillColor=NV;h.cell.styles.textColor=WH;h.cell.styles.fontStyle="bold";h.cell.styles.fontSize=11}}});y=d.lastAutoTable.finalY+18;
 const list=(t,s)=>{const L=C(s).split("\n").map(x=>x.trim()).filter(Boolean);if(!L.length)return;H(t);T(9,[20,33,61]);L.forEach(x=>{const w=d.splitTextToSize("•  "+x,W-2*M-10);if(y+w.length*12>770){d.addPage();y=50}d.text(w,M+6,y);y+=w.length*12+2});y+=10};
 list("KEY BENEFITS",q.benefits);list("ADD-ONS / RIDERS INCLUDED",q.addons);list("KEY EXCLUSIONS / CONDITIONS",q.excl);list("REMARKS",q.qnotes);
 H("TERMS & NOTES");T(8,GR);const tm=["This quotation is indicative and based on the information provided by you. Final premium, coverage and acceptance are subject to the insurer's underwriting guidelines and policy terms & conditions.","Premium and benefits are valid until "+(q.valid||"the date mentioned above")+" and may change thereafter.","Please read the policy wordings, benefit illustration and exclusions carefully before purchase.","Insurance is the subject matter of solicitation."];
 tm.forEach((x,i)=>{const w=d.splitTextToSize((i+1)+".  "+x,W-2*M-10);if(y+w.length*10>770){d.addPage();y=50}d.text(w,M+6,y);y+=w.length*10+3});
 y+=14;if(y>740){d.addPage();y=50}T(10,NV,1);d.text("Thank you for choosing "+CO.name+".",M,y);T(8.5,GR);d.text("For any clarification please call "+CO.phone+" or write to "+CO.email,M,y+13);
 const n=d.getNumberOfPages();for(let i=1;i<=n;i++){d.setPage(i);d.setDrawColor(212,160,23);d.setLineWidth(1);d.line(M,806,W-M,806);T(7,GR);d.text(CO.name+"  |  "+CO.addr+"  |  "+CO.email+"  |  "+CO.phone,W/2,817,{align:"center"});if(n>1)d.text("Page "+i+" of "+n,W-M,829,{align:"right"})}
 await saveFile("Quotation_"+C(q.qno).replace(/\W+/g,"_")+"_"+(C(q.qname)||"Customer").replace(/\W+/g,"_")+".pdf",d.output("arraybuffer"),true)}
