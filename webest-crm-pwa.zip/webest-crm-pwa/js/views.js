/* Webest CRM – Leads, customers, policies, claims, home */
// ---- Leads
function leadForm(id,pre){const e=id&&S0.leads.find(l=>l.id===id);
 draw({title:e?"Edit Lead":"New Lead",d:e?{...e}:{id:uid("L"),created:today(),cat:"Life",status:"New",source:"Direct Walk-in",next:plus(1),...pre},re:["cat"],
 secs:d=>[S("Basic Details",LB),S((d.cat||"Life")+" Interest",LC[d.cat||"Life"]),S("Follow-up",FU)],
 note:e?qCard("lead",id):"",extra:e?`<button class="gold" style="background:var(--ok);color:#fff" onclick="conv()">✅ Convert to Customer</button><button class="ghost" onclick="leadQuote('${id}')">📝 Quotation</button>`:"",
 save:d=>{const i=S0.leads.findIndex(l=>l.id===d.id);i<0?S0.leads.unshift(d):S0.leads[i]=d;save();toast("Lead saved");nav("leads")},
 del:e&&(()=>{S0.leads=S0.leads.filter(l=>l.id!==id);S0.quotes=S0.quotes.filter(q=>q.refId!==id);save();nav("leads")}),back:()=>nav("leads")})}
window.conv=()=>{const m=collect(cur,1);if(m.length){toast("Required: "+m[0]);return}const d=cur.d;
 const c={id:uid("C"),created:today(),pols:[],refCid:d.refCid||"",refby:d.refby||"",fromLead:{source:d.source,created:d.created,notes:d.notes,cat:d.cat}};"name mobile alt email dob gender city occ income".split(" ").forEach(k=>c[k]=d[k]||"");
 S0.custs.unshift(c);S0.leads=S0.leads.filter(l=>l.id!==d.id);S0.quotes.forEach(q=>{if(q.forType==="lead"&&q.refId===d.id){q.forType="cust";q.refId=c.id}});save();toast("Moved to Customers – add policy now");nav("cust",c.id)};
window.refLead=id=>{const c=cust(id);leadForm(0,{refCid:id,refby:c.name,source:"Referral"})};
let LF={st:"All",src:"All"};
function leads(){const f=B||"All",t=today(),L=S0.leads.filter(l=>(f==="All"||l.cat===f)&&(LF.st==="All"||l.status===LF.st)&&(LF.src==="All"||l.source===LF.src)),dn=S0.leads.filter(l=>l.next&&l.next<=t&&!["Won","Lost"].includes(l.status)).length;
 const sl=(k,a)=>`<select onchange="LF.${k}=this.value;nav('leads',0,'${f}')">${["All",...a].map(x=>`<option ${x===LF[k]?"selected":""}>${x}</option>`).join("")}</select>`;
 $("#app").innerHTML=`<div class="row"><button class="gold" onclick="leadForm()">➕ New Lead</button>${dn?`<span class="tag over">⏰ ${dn} follow-up(s) due</span>`:""}</div><div class="tabs">${["All","Life","Health","General"].map(c=>`<button class="${f===c?"on":""}" onclick="nav('leads',0,'${c}')">${c}</button>`).join("")}</div><div class="grid"><div><label>Status</label>${sl("st",FU[0][3])}</div><div><label>Lead Source</label>${sl("src",SRC.split(","))}</div></div><div class="card" style="margin-top:10px"><h2>Leads (${L.length})</h2>${L.length?L.map(l=>`<div class="it" onclick="leadForm('${l.id}')"><div><b>${esc(l.name)}</b><small>${esc(l.mobile)} · ${esc(l.city)}${l.refby?" · Ref: "+esc(l.refby):""}</small><br>${tag(l.cat)}<span class="tag">${esc(l.status)}</span><span class="tag">${esc(l.source)}</span></div><small class="${l.next&&l.next<t&&!["Won","Lost"].includes(l.status)?"over":l.next===t?"today":""}">${l.next?"📅 "+l.next+(l.ftime?"<br>⏰ "+l.ftime:""):""}</small></div>`).join(""):'<div class="empty">No leads match</div>'}</div>`}
window.leadForm=leadForm;
// ---- Customers
function custForm(id,pre){const e=id&&cust(id);
 draw({title:e?"Edit Customer":"New Customer",d:e?{...e}:{id:uid("C"),created:today(),pols:[],docs:[],...pre},
 secs:()=>[S("Personal Details",CB),S("KYC & Occupation",CK),S("Bank Details",CBK),S("Health Profile",CH)],
 save:d=>{if(d.famhead&&S0.custs.some(x=>x.famhead===d.id)){toast("This customer is a Family Head – remove members first");return}const i=S0.custs.findIndex(c=>c.id===d.id);i<0?S0.custs.unshift(d):S0.custs[i]=d;save();toast("Customer saved");nav("cust",d.id)},
 del:e&&(()=>{S0.custs=S0.custs.filter(c=>c.id!==id);S0.claims=S0.claims.filter(x=>x.cid!==id);S0.quotes=S0.quotes.filter(q=>q.refId!==id);save();nav("custs")}),back:()=>nav(e?"cust":"custs",id)})}
window.custForm=custForm;
function custs(){const q=(B||"").toLowerCase();const L=S0.custs.filter(c=>!q||(c.name+c.mobile+c.city).toLowerCase().includes(q));
 $("#app").innerHTML=`<div class="row"><button class="gold" onclick="custForm()">➕ New Customer</button></div><input id="q" placeholder="🔍 Search name / mobile / city" value="${esc(B||"")}" style="margin-bottom:10px"><div class="card"><h2>Customers (${L.length})</h2>${L.length?L.map(c=>`<div class="it" onclick="nav('cust','${c.id}')"><div><b>${esc(c.name)}</b><small>${esc(c.mobile)} · ${esc(c.city)}</small><br>${famTag(c)}${["Life","Health","General"].map(k=>{const n=c.pols.filter(p=>p.cat===k).length;return n?`<span class="tag ${k}">${k} × ${n}</span>`:""}).join("")||'<span class="tag">No policy yet</span>'}</div><small>${c.pols.length} policies</small></div>`).join(""):'<div class="empty">No customers yet. Convert a lead or add one.</div>'}</div>`;
 const i=$("#q");i.oninput=e=>{const p=e.target.selectionStart;nav("custs",0,e.target.value);const n=$("#q");n.focus();n.setSelectionRange(p,p)}}
function custView(){const c=cust(A);if(!c){nav("custs");return}const cl=S0.claims.filter(x=>x.cid===c.id);const t=today(),qs=S0.quotes.filter(q=>q.forType==="cust"&&q.refId===c.id);
 const mi=c.dob&&age(c.dob)<18;
 $("#app").innerHTML=`<div class="row"><button class="ghost" onclick="nav('custs')">← Back</button><button class="ghost" onclick="custForm('${c.id}')">✏️ Edit</button><button class="ghost" onclick="pdf(cust('${c.id}'))">📄 PDF</button></div>
 <div class="card"><h2>${esc(c.name)} ${mi?'<span class="tag over">Minor</span>':""}</h2><div class="kv"><div><span>Mobile</span><br>${esc(c.mobile)}</div><div><span>Email</span><br>${esc(c.email)||"-"}</div><div><span>DOB</span><br>${c.dob||"-"}${c.dob?" ("+age(c.dob)+" yrs)":""}</div><div><span>City</span><br>${esc(c.city)||"-"}</div><div><span>Referrals Given</span><br>${S0.leads.concat(S0.custs).filter(x=>x.refCid===c.id).length}</div><div><span>Source</span><br>${c.fromLead?esc(c.fromLead.source)+" (lead "+c.fromLead.created+")":"Direct"}</div></div>
 <div class="row" style="margin-top:10px"><a href="tel:${esc(c.mobile)}"><button class="sm">📞 Call</button></a><button class="sm gold" onclick="refLead('${c.id}')">+ Reference Lead</button><button class="sm" style="background:var(--ok)" onclick="waPick('${c.id}')">💬 WhatsApp</button></div></div>
 <div class="card"><h2>Policies (${c.pols.length})</h2><div class="row"><button class="sm gold" onclick="polForm('${c.id}',0,'Life')">+ Life</button><button class="sm gold" onclick="polForm('${c.id}',0,'Health')">+ Health</button><button class="sm gold" onclick="polForm('${c.id}',0,'General')">+ General</button></div>
 ${c.pols.length?c.pols.map(p=>`<div class="it" style="cursor:default"><div>${tag(p.cat)}<span class="tag">${esc(p.status)}</span><b>${esc(p.insurer)} – ${esc(p.polno)}</b><small>${esc(p.plan||p.type||"")} · ₹${esc(p.premium)||0}/${esc(p.mode)||""} · Sum ₹${esc(p.sum)||0} · Comm ₹${cexp(p)}</small><br><small class="${p.due&&p.due<t&&p.status==="Active"?"over":""}">Due: ${p.due||"-"}</small></div><div class="row" style="flex-direction:column;align-items:stretch"><button class="sm ghost" onclick="polForm('${c.id}','${p.id}','${p.cat}')">Edit</button><button class="sm ghost" onclick="claimForm('${c.id}','${p.id}')">+ Claim</button><button class="sm ghost" onclick="waPick('${c.id}','${p.id}')">💬 Message</button></div></div>`).join(""):'<div class="empty">No policies yet – add one above</div>'}</div>
 ${famCard(c)}${docCard(c)}<div class="card"><h2>Quotations (${qs.length})</h2><div class="row"><button class="sm gold" onclick="custQuote('${c.id}')">+ New Quotation</button></div>${qs.map(qrow).join("")||'<div class="empty">No quotations yet</div>'}</div><div class="card"><h2>Claims (${cl.length})</h2>${cl.length?cl.map(claimRow).join(""):'<div class="empty">No claims</div>'}</div>`}
// ---- Policies
function polSecs(d,c){const cat=d.cat,s=[S("Policy Details",PC)];
 if(cat==="Life"){s.push(S("Life Plan, Riders & Payment",LP),S("Family History",FAM),S("Nominee",NOM),S("Appointee (if nominee is minor)",APP),S("Corona Questionnaire",COV),S("Documents",DOC));if(c.gender==="Female")s.push(S("Female Questionnaire",FEM))}
 else if(cat==="Health"){const fl=d.type==="Family Floater";s.push(S("Health Cover",fl?HB.concat(P("nmem|Total Family Members to Cover *|s|2,3,4,5,6,7,8")):HB));
  if(fl){const n=+d.nmem||2;for(let i=0;i<n;i++)s.push(S("👨‍👩‍👧 Member "+(i+1),MF,"m"+i+"_"))}else s.push(S("Insured Health Details",HI))}
 else{s.push(S("Insurance Requirement",GR));if(GT[d.type])s.push(S(d.type+" Details",GT[d.type]));s.push(S("Nominee / Claim Contact",GN),S("Document Checklist",GD),S("For Advisor Use",GAD))}
 s.push(S("Commission & Payout",CM));if(c.dob&&age(c.dob)<18)s.push(S("⚠️ Proposer Details – Life Assured is below 18 (mandatory)",PR));return s}
function polForm(cid,pid,cat){const c=cust(cid),e=pid&&c.pols.find(p=>p.id===pid);
 draw({title:`${e?"Edit":"Add"} ${cat} Policy – ${esc(c.name)}`,d:e?{...e}:{id:uid("P"),cat,status:"Active",start:today(),...(cat==="General"?{type:"Private Car"}:{})},re:["type"].concat(cat==="Health"?["nmem"]:[]),
 note:c.dob?(age(c.dob)<18?`<div class="card" style="border-color:var(--bad)">Customer is ${age(c.dob)} yrs (minor). Proposer details are required.</div>`:""):`<div class="card">Add customer's Date of Birth to enable the minor / proposer check.</div>`,
 secs:d=>polSecs(d,c),
 save:d=>{const i=c.pols.findIndex(p=>p.id===d.id);i<0?c.pols.push(d):c.pols[i]=d;save();toast("Policy saved");nav("cust",cid)},
 del:e&&(()=>{c.pols=c.pols.filter(p=>p.id!==pid);S0.claims=S0.claims.filter(x=>x.pid!==pid);save();nav("cust",cid)}),back:()=>nav("cust",cid)})}
window.polForm=polForm;
// ---- Claims
const open=x=>!["Settled","Rejected"].includes(x.status);
function claimRow(x){const c=cust(x.cid),p=c&&c.pols.find(p=>p.id===x.pid);return`<div class="it" onclick="claimForm('${x.cid}','${x.pid}','${x.id}')"><div><b>${esc(c?c.name:"?")} – ${esc(x.type)}</b><small>${p?esc(p.insurer)+" · "+esc(p.polno):""} · ₹${esc(x.amt)||0}</small><br><span class="tag">${esc(x.status)}</span></div><small>${x.next?"📅 "+x.next:""}</small></div>`}
function claimForm(cid,pid,id){const e=id&&S0.claims.find(x=>x.id===id),c=cust(cid),p=c.pols.find(p=>p.id===pid);
 draw({title:`${e?"Edit":"New"} Claim – ${esc(c.name)} (${esc(p.polno)})`,d:e?{...e}:{id:uid("X"),cid,pid,status:"Intimated",dint:today(),next:plus(2),type:p.cat==="Life"?"Death":p.cat==="Health"?"Hospitalisation – Cashless":"Own Damage"},secs:()=>[S("Claim Details",CL)],
 save:d=>{const i=S0.claims.findIndex(x=>x.id===d.id);i<0?S0.claims.unshift(d):S0.claims[i]=d;save();toast("Claim saved");nav("claims")},
 del:e&&(()=>{S0.claims=S0.claims.filter(x=>x.id!==id);save();nav("claims")}),back:()=>nav("claims")})}
window.claimForm=claimForm;
function claims(){const f=B||"Open";const L=S0.claims.filter(x=>f==="All"||(f==="Open")===open(x));
 $("#app").innerHTML=`<div class="tabs">${["Open","Closed","All"].map(c=>`<button class="${f===c?"on":""}" onclick="nav('claims',0,'${c}')">${c}</button>`).join("")}</div><div class="card"><h2>Claims (${L.length})</h2>${L.length?L.map(claimRow).join(""):'<div class="empty">No claims. Open a customer → policy → “+ Claim”.</div>'}</div>`}
// ---- Home
function home(){const t=today(),o=S0.leads.filter(l=>!["Won","Lost"].includes(l.status)&&l.next);const ov=o.filter(l=>l.next<t),td=o.filter(l=>l.next===t),lim=plus(30);
 const ren=[];S0.custs.forEach(c=>c.pols.forEach(p=>{if(p.status==="Active"&&p.due&&p.due<=lim)ren.push({c,p})}));ren.sort((a,b)=>a.p.due>b.p.due?1:-1);
 const li=l=>`<div class="it" onclick="leadForm('${l.id}')"><div><b>${esc(l.name)}</b><small>${tag(l.cat)} ${esc(l.status)} · ${l.next} ${l.ftime||""}</small></div><div class="row" style="margin:0"><a href="tel:${esc(l.mobile)}" onclick="event.stopPropagation()"><button class="sm">Call</button></a></div></div>`;
 const sec=(h,a,f,c)=>`<div class="card"><h2 class="${c||""}">${h} (${a.length})</h2>${a.length?a.map(f).join(""):'<div class="empty">Nothing here 👍</div>'}</div>`;
 $("#app").innerHTML=`${bkBanner()}<div class="stats"><div class="stat"><b>${S0.leads.length}</b><span>Total Leads</span></div><div class="stat"><b>${S0.custs.length}</b><span>Customers</span></div><div class="stat"><b>${S0.custs.reduce((a,c)=>a+c.pols.length,0)}</b><span>Policies</span></div><div class="stat"><b>${S0.claims.filter(open).length}</b><span>Open Claims</span></div><div class="stat"><b>${S0.custs.filter(c=>c.fromLead).length}</b><span>Leads Converted</span></div><div class="stat"><b>${S0.leads.concat(S0.custs).filter(x=>x.refCid).length}</b><span>Referral Leads</span></div><div class="stat"><b>${S0.quotes.length}</b><span>Quotations</span></div><div class="stat"><b>${S0.quotes.filter(q=>q.status==="Accepted").length}</b><span>Quotes Accepted</span></div></div>${chartsCard()}
 ${sec("⚠️ Overdue follow-ups",ov,li,"over")}${sec("📞 Today's follow-ups",td,li,"today")}
 ${sec("🔔 Renewals / premiums due (30 days)",ren,({c,p})=>`<div class="it" onclick="nav('cust','${c.id}')"><div><b>${esc(c.name)}</b><small>${tag(p.cat)} ${esc(p.insurer)} · ${esc(p.polno)}</small></div><small class="${p.due<t?"over":""}">${p.due}</small></div>`)}
 ${sec("📑 Open claims",S0.claims.filter(open),claimRow)}
 <div class="row"><button class="gold" onclick="leadForm()">➕ New Lead</button><button onclick="custForm()">➕ New Customer</button></div>`}
