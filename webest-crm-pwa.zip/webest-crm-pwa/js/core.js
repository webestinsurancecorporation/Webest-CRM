/* Webest CRM – Storage, helpers, form engine, router */
// ---- helpers
const K="webest_crm_v2",DK="__data__";let S0={leads:[],custs:[],claims:[]},V="home",A,B,cur;
/* All data lives in this browser's IndexedDB (no server, no login). */
const save=()=>{idbPut(DK,S0).catch(()=>toast("⚠️ Could not save – device storage full?"))};
function normalize(){S0.leads=S0.leads||[];S0.custs=S0.custs||[];S0.claims=S0.claims||[];S0.quotes=S0.quotes||[];S0.set=S0.set||{};S0.set.comm=S0.set.comm||{};S0.set.tpl=S0.set.tpl||{};S0.leads.forEach(l=>{if(l.source==="Walk-in")l.source="Direct Walk-in"});S0.custs.forEach(c=>{c.docs=c.docs||[];c.pols=c.pols||[]})}
async function loadData(){let d=null;try{d=await idbGet(DK)}catch(e){}
 if(!d){try{const r=localStorage.getItem(K);if(r){d=JSON.parse(r);await idbPut(DK,d)}else{const o=localStorage.getItem("webest_leads_v1");if(o)d={leads:JSON.parse(o),custs:[],claims:[]}}}catch(e){}}
 if(d)S0=d;normalize()}
let UI={charts:true};try{UI=JSON.parse(localStorage.getItem(K+"_ui"))||UI}catch(e){}
const $=s=>document.querySelector(s),uid=p=>p+Date.now().toString(36)+Math.random().toString(36).slice(2,5);
const esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const ds=d=>{const z=new Date(d.getTime()-d.getTimezoneOffset()*6e4);return z.toISOString().slice(0,10)},today=()=>ds(new Date()),plus=n=>ds(new Date(Date.now()+n*864e5));
const age=d=>Math.floor((Date.now()-new Date(d))/31557600000);
const toast=m=>{const t=$("#toast");t.textContent=m;t.style.display="block";setTimeout(()=>t.style.display="none",2400)};
const S=(t,f,pre="")=>({t,f,pre});
const IT={n:"number",d:"date",e:"email",m:"tel",time:"time",t:"text"};
function fld([k,l,t,o],v,pre){const id="f_"+pre+k;v=v??"";
 if(t==="C"){const me=cur.d.id;return`<div class="full"><label>${l}</label><select id="${id}"><option value="">— None (independent / is a Family Head) —</option>${S0.custs.filter(x=>x.id!==me&&!x.famhead).map(x=>`<option value="${x.id}" ${x.id==v?"selected":""}>${esc(x.name)}</option>`).join("")}</select></div>`}
 if(t==="c"){const vs=String(v).split(", ");return`<div class="full"><label>${l}</label><div id="${id}" class="chk">${o.map(x=>`<label class="ck"><input type="checkbox" value="${x}" ${vs.includes(x)?"checked":""}>${x}</label>`).join("")}</div></div>`}
 if(t==="s")return`<div><label>${l}</label><select id="${id}">${o.map(x=>`<option ${x==v?"selected":""}>${x}</option>`).join("")}</select></div>`;
 if(t==="a")return`<div class="full"><label>${l}</label><textarea id="${id}">${esc(v)}</textarea></div>`;
 return`<div><label>${l}</label><input id="${id}" type="${IT[t]||"text"}" value="${esc(v)}"></div>`}
function draw(c){cur=c;const secs=c.secs(c.d);
 $("#app").innerHTML=`<h2 class="ttl">${c.title}</h2>`+(c.note||"")+secs.map(s=>`<div class="card"><h2>${s.t}</h2><div class="grid">${s.f.map(f=>fld(f,c.d[s.pre+f[0]],s.pre)).join("")}</div></div>`).join("")+`<div class="row"><button class="gold" onclick="FS()">💾 Save</button>${c.extra||""}${c.del?`<button class="ghost" style="color:var(--bad)" onclick="FD()">Delete</button>`:""}<button class="ghost" onclick="cur.back()">Cancel</button></div>`;
 (c.re||[]).forEach(k=>{const e=$("#f_"+k);if(e)e.onchange=()=>{collect(c);draw(c)}});scrollTo(0,0)}
function collect(c,chk){const m=[];c.secs(c.d).forEach(s=>s.f.forEach(f=>{const e=$("#f_"+s.pre+f[0]);if(!e)return;const v=e.tagName==="DIV"?[...e.querySelectorAll("input:checked")].map(i=>i.value).join(", "):e.value.trim();c.d[s.pre+f[0]]=v;if(chk&&f[1].endsWith("*")&&!v)m.push(f[1].replace(" *",""))}));return m}
window.FS=()=>{const m=collect(cur,1);if(m.length){toast("Required: "+m[0]);return}cur.save(cur.d)};
function modal(h){let m=$("#md");if(!m){m=document.createElement("div");m.id="md";document.body.appendChild(m)}m.innerHTML=h?`<div class="mb"><div class="mc">${h}</div></div>`:""}
window.modal=modal;window.FD=()=>{const f=cur.del;window._ok=f;modal(`<h2>🗑️ Delete?</h2><p>This record will be removed permanently.</p><div class="row"><button style="background:var(--bad)" onclick="modal();_ok()">Yes, Delete</button><button class="ghost" onclick="modal()">Cancel</button></div>`)};
const nav=(v,a,b)=>{V=v;A=a;B=b;try{history.pushState({v,a,b},"")}catch(e){}route();scrollTo(0,0)};window.nav=nav;window.addEventListener("popstate",e=>{if(e.state){V=e.state.v;A=e.state.a;B=e.state.b;modal();route()}});window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();window._ip=e});
function route(){const g={home:"home",leads:"leads",custs:"custs",cust:"custs",claims:"claims",quotes:"quotes",more:"more",earn:"more",wa:"more",set:"more",family:"custs"}[V];document.querySelectorAll("nav button[data-v]").forEach(b=>b.classList.toggle("on",b.dataset.v===g));({home,leads,custs,claims,quotes,more,earn,wa:waCenter,set:settings,family,cust:custView})[V]()}
const cust=id=>S0.custs.find(c=>c.id===id);
const tag=(c)=>`<span class="tag ${c}">${c}</span>`;
