# Webest Insurance Corporation – CRM (Standalone PWA)

Runs directly in Chrome / Android. **No Claude login, no server, no database.**
Data is stored on the phone (IndexedDB). Works offline after the first load.

## Folder structure
```
webest-crm-pwa/
├── index.html              App shell
├── manifest.json           PWA manifest (name, icons, shortcuts)
├── service-worker.js       Offline cache  (bump CACHE_VERSION on every update)
├── README.md
├── css/style.css           All styles
├── js/
│   ├── fields.js           Form field definitions (lead, customer, policy, quote…)
│   ├── core.js             IndexedDB load/save, helpers, form engine, router
│   ├── views.js            Leads, Customers, Policies, Claims, Home
│   ├── charts-quotes.js    Analytics graphs + Quotations
│   ├── extras.js           Family, KYC docs, Commission, WhatsApp, Alerts, Settings
│   ├── backup.js           Downloads, file storage, Backup/Restore, Excel, PDF
│   └── main.js             Startup, service-worker registration
├── libs/                   xlsx.full.min.js, jspdf.umd.min.js, jspdf.plugin.autotable.min.js (local copies)
├── icons/                  icon-192.png, icon-512.png, icon-maskable-512.png
└── images/banner.jpg       Header banner (also used in PDFs)
```

## Deploy (free, needs HTTPS)
**A) Netlify Drop (easiest):** open https://app.netlify.com/drop → drag the whole `webest-crm-pwa` folder → you get an https link.
**B) GitHub Pages:** new repo → upload all files (keep folders) → Settings → Pages → Deploy from branch `main` / root.
**C) Test on PC first:** in the folder run `python3 -m http.server 8080` → open http://localhost:8080

## Install on Android
Chrome → open your link → ⋮ menu → **Install app** (or Add to Home screen). Also: More → 📲 Install App.

## Make an .apk (optional)
https://www.pwabuilder.com → paste your https link → Package for Android → download. Keep the signing key safe.

## Updating the app later
Replace the files on your host, then change `CACHE_VERSION` in service-worker.js (e.g. v3 → v4). Open the app twice to load the update. Data is not touched.

## Backup / Restore (important)
More → Backup → **Full Backup (.json)** = all data + uploaded documents. Home shows a reminder if no backup for 7 days.
More → **Restore from Backup** to load the file on the same or a new phone. Excel / PDF exports are for reading, not restoring.
Clearing browser/site data deletes the app data – always keep a backup copy (Google Drive / WhatsApp).

## Known limits
- PDF text is Latin only (Tamil script does not render in PDFs; Excel is fine).
- Reminders pop up only while the app is open (no server push).
- WhatsApp cannot auto-attach files: download/share the PDF, then attach it in chat.
